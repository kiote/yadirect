require 'rubygems'
require 'bundler/setup'

RSpec.configure do |config|
  # some (optional) config here
end
