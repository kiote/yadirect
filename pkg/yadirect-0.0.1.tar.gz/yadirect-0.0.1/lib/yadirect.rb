module Yadirect
  require 'proxy'
end

